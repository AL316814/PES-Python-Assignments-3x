#Strings
'''
30.Write a program to Sort given N numbers
( Use only loop structures and Conditions to sort the elements. Use Bubble sort / Selection sort technique to sort the elements of List)
Note : don't use built in functions to sort.
'''
str1=input("Enter the numbers")
list1=list(str1)
for each in range(len(list1)):
  swap=False
  i = 0
  while i<len(list1)-1:
    if list1[i]>list1[i+1]:
      list1[i],list1[i+1] = list1[i+1],list1[i]
      swap = True
    i = i+1
  if swap == False:
    break
print (list1)

'''
def bubbleSort(arr):
	n = len(arr)

	# Traverse through all array elements
	for i in range(n):

		# Last i elements are already in place
		for j in range(0, n-i-1):

			# traverse the array from 0 to n-i-1
			# Swap if the element found is greater
			# than the next element
			if arr[j] > arr[j+1] :
				arr[j], arr[j+1] = arr[j+1], arr[j]

# Driver code to test above
arr = [64, 34, 25, 12, 22, 11, 90]

bubbleSort(arr)

print ("Sorted array is:")
for i in range(len(arr)):
	print ("%d" %arr[i]), 
'''