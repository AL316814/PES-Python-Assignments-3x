#Strings
'''26.Receive the encoded string from your friend and decode it to check the original message. PS: You will receive Encoded string and the Algorithm used for encoding.'''
encStr = "dGhpcyBpcyB0byBjaGVjayBmb3IgZW5jb2RlIGFuZCBkZWNvZGU="
decStr = encStr.decode('base64','strict')
print "Encoded String: " + encStr
print "Decoded String: " + decStr
